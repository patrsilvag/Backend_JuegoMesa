package tareas.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuegosMesaApplication {

    public static void main(String[] args) {
        SpringApplication.run(JuegosMesaApplication.class, args);
    }
}
